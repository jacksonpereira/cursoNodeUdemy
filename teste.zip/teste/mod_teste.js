module.exports = function () {
    var msg = "Este módulo contém apenas uma string";
    return msg;
}