module.exports = function (app) {
    app.get('/', function (req, res) {
        console.log("Entrou!");
        res.render("home/index");
    })
}