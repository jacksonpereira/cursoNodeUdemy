module.exports = function (app) {
    app.get('/noticias', function (req, res) {
        console.log("Entrou!");
        var mysql = require('mysql');
        var connection = mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password: '1234',
            database: 'portal_noticias'
        });

        connection.query('select * from noticias;', function (erro, result) {
            if (erro) {
                console.log("Erro ao buscar no banco de dados!");
            } else {
                res.send(result);
            }
        });
        //res.render("noticias/noticias");
    });
}